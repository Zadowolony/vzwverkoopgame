<body>
    <?php $__env->startSection('title', 'Registreren'); ?>

    <?php $__env->startSection('content'); ?>
        <main>
            <section class="bg-appleblue ">

                <div class="container">
                    <div class="row register-container">

                        <div class="col-12 col-md-6  register-container-left ">
                            <div class="col-11">
                                <div class="login-textbox-1">

                                    <span class="login-text-1">welcome op de</span>
                                </div>
                                <div class="login-textbox-2">
                                    <span class="login-text-2">vzw</span>
                                    <span class="login-text-3">donate</span>
                                    <span class="login-text-4">games</span>
                                </div>
                                <div>

                                    <span class="login-text-5 ">registreer pagina</span>
                                </div>
                            </div>
                        </div>

                        <div class="col-10 col-md-6 register-container-right">

                            <div class="col-12 form-register-container">


                                <h2>Vul je gegevens in</h2>

                                <form action="<?php echo e(route('register.post')); ?>" method="post" enctype="multipart/form-data"
                                    novalidate>
                                    <?php echo csrf_field(); ?>
                                    <div class="col-7">
                                        <label for="name">Kies een Gebruikersnaam:</label>
                                        <input name="name" type="text" id="name"
                                            placeholder="Kies je gebruikersnaam..." value="<?php echo e(old('name')); ?>">
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <label for="profile_picture">Kies een profielfoto:</label>
                                        <input class="profile_picture-button" type="file" id="profile_picture"
                                            name="profile_picture">
                                        <?php $__errorArgs = ['profile_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <label for="email">Kies een email:</label>
                                        <input name="email" type="email" placeholder="Email adress" id="email"
                                            value="<?php echo e(old('email')); ?>">
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <label for="name">Kies een wachtwoord:</label>
                                        <input name="password" type="password" placeholder="wachtwoord"
                                            value="<?php echo e(old('password')); ?>">
                                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <label for="name">Herhaal je wachtwoord:</label>
                                        <input name="password_confirmation" type="password"
                                            placeholder="Confirmeer je wachtwoord">
                                        <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div>
                                        <button type="submit">Registreer</button>
                                    </div>
                                </form>
                                <div class="m-t-25 m-b-25">
                                    <p>Heb je een login pagina?</p>
                                    <a href="<?php echo e(route('login')); ?>">Login >>></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


            </section>

            <section>

            </section>
        </main>
    <?php $__env->stopSection(); ?>





</body>

</html>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/auth/register.blade.php ENDPATH**/ ?>