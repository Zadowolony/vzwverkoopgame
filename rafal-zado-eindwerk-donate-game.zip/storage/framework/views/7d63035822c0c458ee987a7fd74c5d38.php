<div class="col-6 col-xs-4 col-md-3 card-link ">

    <div class="game-card full-card-link bg-yellow  gap-20">


        <div>
            <img src="<?php echo e(asset('storage/' . $game->foto)); ?>" alt="Profile Picture">
        </div>
        <div class="game-card-info">
            <h3><?php echo e($game->titel); ?></h3>

        </div>
        <div class="row col-12 justify-end gap20 wishlist-card-icons-box ">

            <form action="<?php echo e(route('wishlist.remove', $game->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="remove-btn">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </form>

        </div>




    </div>

</div>
<?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\profile\layouts\includes\wishlist-card.blade.php ENDPATH**/ ?>