<body>

    <?php $__env->startSection('content'); ?>
        <section class="bg-appleblue">

            <div class="container">
                <div class="row justify-center succes-flash">
                    <?php if(session('succes')): ?>
                        <?php echo e(session('succes')); ?>

                    <?php endif; ?>

                </div>
            </div>





            <section class="row container login-container flex-wrap  ">


                <div class="col-11 col-md-6  login-container-left  p-t-50">
                    <div>
                        <div class="m-b--35">

                            <span class="login-text-1">welcome op de</span>
                        </div>
                        <div class="">
                            <span class="login-text-2">vzw</span>
                            <span class="login-text-3">donate</span>
                            <span class="login-text-4">games</span>
                        </div>
                        <div class="text-right ">

                            <span class="login-text-5 ">login pagina</span>
                        </div>
                    </div>
                </div>

                <div class="col-9 col-md-6 login-container-right p-b-50">
                    <div class=" col-12 col-md-10 form-login-container ">

                        <h2>Login</h2>
                        <form action="<?php echo e(route('login.post')); ?>" method="post" novalidate>
                            <?php echo csrf_field(); ?>
                            <div>
                                <label for="email">Login met je email:</label>
                                <input id="email" name="email" type="email" placeholder="email"
                                    value="<?php echo e(old('email')); ?>">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-box">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div>
                                <label for="password"> Jouw wachtwoord:</label>
                                <input name="password" type="password" placeholder="password" value="<?php echo e(old('password')); ?>">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-box">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div>
                                <button type="submit">Log In</button>
                            </div>
                        </form>
                        <div>
                            <p class="m-t-30">Heb je nog geen account?</p>
                            <a href="<?php echo e(route('register')); ?>">Klick hier >></a>
                        </div>
                    </div>
                </div>








            </section>


        </section>
    <?php $__env->stopSection(); ?>





</body>

</html>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\auth\login.blade.php ENDPATH**/ ?>