<body>
    <?php $__env->startSection('content'); ?>
        <main class="bg-appleblue">
            <div class="container-full bg-yellow">

                <div class="container container-show-game row col-12 ">

                    <div class="col-12 col-md-5 ">
                        <img src="<?php echo e(asset('storage/' . $game->foto)); ?>" alt="<?php echo e($game->titel); ?>">
                    </div>

                    <div class="p-b-25 col-md-5">
                        <h2 class="p-b-10"><?php echo e($game->titel); ?></h2>
                        <p>
                        <p><?php echo e($game->game_beschrijving); ?></p>
                        </p>
                        <div class="game_category_console col-2">
                            <p><?php echo e(implode(', ', $game->platforms->pluck('platform_naam')->toArray())); ?></p>
                        </div>

                        <?php if(auth()->check()): ?>
                            <?php
                                $isOnWishlist = DB::table('wishlist_items')
                                    ->where('user_id', auth()->id())
                                    ->where('game_id', $game->id)
                                    ->exists();
                            ?>

                            <?php if(!$isOnWishlist): ?>
                                <form action="<?php echo e(route('wishlist.add', $game->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="game_id" value="<?php echo e($game->id); ?>">
                                    <button type="submit" class="btn btn-primary">Add to Wishlist</button>
                                </form>
                            <?php else: ?>
                                <button class="btn btn-secondary" disabled>Already on Wishlist</button>
                            <?php endif; ?>
                        <?php endif; ?>


                    </div>


                </div>




                <div class="container">
                    <div class="col-12 col-md-12 p-b-50">


                        <div class="col-12">
                            <h2 class="p-b-20">Verkopers :</h2>
                            <?php $__currentLoopData = $userGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $userGame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($userGame->status === 'te koop' && $userGame->user_id != auth()->id()): ?>
                                    <div class="game-verkopers-tabel <?php echo e($index % 2 == 0 ? 'bg-appleblue' : 'bg-yellow'); ?>">
                                        <h3><?php echo e($userGame->user->name); ?></h3>
                                        <p>€<?php echo e($userGame->prijs); ?></p>
                                        <p><?php echo e($userGame->conditie); ?></p>

                                        <button
                                            onclick="location.href='<?php echo e(route('verkoop.show', $userGame->id)); ?>'">Kopen</button>
                                <?php endif; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
            </div>


        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\game\show.blade.php ENDPATH**/ ?>