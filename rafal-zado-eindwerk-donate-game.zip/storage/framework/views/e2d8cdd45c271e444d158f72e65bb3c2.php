<body>
    <?php $__env->startSection('profile-content'); ?>
        <main class="bg-appleblue">

            <div class="container h-100 flex align-items-center justify-center">
                <div class="row container-show-game col-12 ">
                    <div class="col-12 col-md-5">
                        <h1 class="text-purple">Verwijder:</h1>
                        <h2><?php echo e($game->titel); ?></h2>
                        <p class="p-t-25 p-b-25">Weet je zeker dat je dit wil verwijderen?</p>
                        <form action="<?php echo e(route('verkoop.destroy', $game->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="button delete-btn">Verwijder dit spel</button>
                        </form>
                    </div>

                    <div class="col-12 col-md-6 flex justify-center ">
                        <img src="<?php echo e(asset('storage/' . $game->foto)); ?>" alt="<?php echo e($game->titel); ?>" style="width: 300px;">
                    </div>


                </div>
            </div>

        </main>
    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\verkoop\delete.blade.php ENDPATH**/ ?>