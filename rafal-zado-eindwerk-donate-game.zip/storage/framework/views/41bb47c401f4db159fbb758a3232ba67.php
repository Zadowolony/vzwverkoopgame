<body>

    <?php $__env->startSection('profile-content'); ?>
        <main class="bg-appleblue">
            <div class="container">
                <div class="row container-show-game col-12">
                    <div class="col-12 col-md-5">
                        <h1 class="text-purple">Update:</h1>
                        <h2><?php echo e($game->titel); ?></h2>
                        <?php if($game->userGames->isNotEmpty()): ?>
                            <p><?php echo e($game->userGames->first()->beschrijving); ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="col-12 col-md-6 flex justify-center ">
                        <img src="<?php echo e(asset('storage/' . $game->foto)); ?>" alt="<?php echo e($game->titel); ?>" style="width: 300px;">
                    </div>


                </div>
            </div>

            <div class="container padding-con">
                <form action="<?php echo e(route('verkoop.update', $game->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div>

                        <div class="row gap10 col-12">

                            <div class="edit-profil-box flex flex-column col-8">
                                <label for="beschrijving">Werk je beschrijving bij : </label>
                                <textarea name="beschrijving" id="beschrijving" cols="30" rows="10"><?php echo e(old('beschrijving', $game->userGames->first()->beschrijving)); ?></textarea>
                            </div>
                        </div>

                        <div>
                            <h2>Kenmerken</h2>
                            <div class="row gap10 col-12">
                                <div class="edit-profil-box flex flex-column col-8">
                                    <label for="conditie">Conditie:</label>
                                    <select id="conditie" name="conditie" value="<?php echo e(old('conditie')); ?>">
                                        <option value="Nieuw">Nieuw</option>
                                        <option value="Zo Goed Als Nieuw">Zo Goed Als Nieuw</option>
                                        <option value="Gebruikt">Gebruikt</option>
                                        <option value="Niet werkend">Niet Werkend</option>
                                        <option value="Nog verpakt">Nog Verpakt</option>


                                    </select>
                                    <?php $__errorArgs = ['conditie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error-box">
                                            <p><?php echo e($message); ?></p>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                </div>
                            </div>
                        </div>
                        <div>
                            <h2>Prijs</h2>
                            <div class="row gap10 col-12">
                                <div class="edit-profil-box flex flex-column col-4">
                                    <label for="prijs ">Prijs:</label>
                                    <input type="number" id="prijs" name="prijs" min="0.01" step="0.01"
                                        value="<?php echo e(old('prijs')); ?>" required>
                                </div>
                                <?php $__errorArgs = ['prijs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-box">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div>
                            <button type="submit">Sla op</button>
                        </div>
                    </div>
                </form>
            </div>
        </main>
    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\verkoop\edit.blade.php ENDPATH**/ ?>