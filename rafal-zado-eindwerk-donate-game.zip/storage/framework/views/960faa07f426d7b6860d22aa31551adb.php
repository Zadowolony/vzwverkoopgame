<!DOCTYPE html>
<html>

<head>
    <title>Game Available for Purchase!</title>
</head>

<body>
    <h1><?php echo e($gameTitle); ?> is Now Available!</h1>
    <p>Description: <?php echo e($gameDescription); ?></p>
    <p>Price: €<?php echo e($gamePrice); ?></p>
    <p>Visit our website to buy it now!</p>
</body>

</html>
<?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\emails\gameAvailable.blade.php ENDPATH**/ ?>