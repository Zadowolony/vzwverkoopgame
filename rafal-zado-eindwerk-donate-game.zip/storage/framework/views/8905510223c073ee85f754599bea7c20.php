<body>
    <?php $__env->startSection('title-profile', 'DonateGames'); ?>
    <?php $__env->startSection('profile-content'); ?>
        <main class="bg-appleblue">
            <div class="container flex flex-column justify-center h-100">
                <div class="row p-t-50 gap50">
                    <div class="col-12 col-md-6 ">
                        <div class="flex justify-center flex-column ">
                            <img class="border-radius-25" src="<?php echo e(asset('storage/' . $game->foto)); ?>"
                                alt="<?php echo e($game->titel); ?>">
                            <?php if(auth()->user() && auth()->user()->isAdmin()): ?>
                                <div class="col-12 p-t-15">
                                    <a class="admin-verwijder-link" href="<?php echo e(route('verkoop.delete', $game->id)); ?>"
                                        class="btn btn-danger">Verwijder
                                        Spel</a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12 p-b-25 col-md-5 flex flex-column justify-center">
                        <div class="col-12 flex justify-center game_titel">
                            <h1><?php echo e($game->titel); ?></h1>
                        </div>
                        <div class="col-12 row align-content-start p-t-50 p-b-25">
                            <div class="col-4 flex align-content-start">
                                <p class="">Reden van verkoop:</p>
                            </div>
                            <div class="col-8">
                                <p><?php echo e($userGame->beschrijving); ?></p>
                            </div>
                        </div>
                        <div class="col-12 row align-items-center">
                            <div class="col-4 flex">
                                <p class="p-t-25">Prijs:</p>
                            </div>
                            <div class="game_category_console col-6">
                                <p>€<?php echo e($userGame->prijs); ?></p>
                            </div>
                        </div>
                        <div class="col-12 row align-items-center">
                            <div class="col-4 flex">
                                <p class="p-t-25">Conditie:</p>
                            </div>
                            <div class="game_category_console col-6">
                                <p class="p-l-10 p-r-10"><?php echo e($userGame->conditie); ?></p>
                            </div>
                        </div>
                        <div class="col-12 row align-items-center">
                            <div class="col-4 flex">
                                <p class="p-t-25">Platform:</p>
                            </div>
                            <div class="game_category_console col-6">
                                <?php $__currentLoopData = $game->platforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $platform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($platform->platform_naam); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <?php if($userGame->status === 'te koop' && $userGame->user_id != auth()->id()): ?>
                            <div class="col-10 p-t-15 buy-btn-box">
                                <form action="<?php echo e(route('verkoop.buy', $userGame->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="buy-btn">Koop het spel van
                                        <?php echo e($userGame->user->name); ?></button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/verkoop/show.blade.php ENDPATH**/ ?>