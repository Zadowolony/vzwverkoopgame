<?php $__env->startSection('title', 'Games'); ?>

<body>

    <?php
        $gameCount = count($games); // Bepaal het aantal games
        $colClass = $gameCount === 1 ? 'col-md-6' : 'col-md-3'; // Conditioneel de kolomklasse instellen
    ?>


    <?php $__env->startSection('content'); ?>
        <main class="bg-main-1 ">


            <div class="container  flex justify-center align-items-center ">
                <div class="p-t-50 p-b-50">
                    <div class="row game-category col-12 justify-center flex">
                        <!-- Category buttons -->
                        <div class="col-12 row justify-center gap20 p-b-50">
                            <a href="<?php echo e(route('games', ['category' => 'retro'])); ?>"
                                class="button <?php echo e(request()->routeIs('games') && request()->input('category') == 'retro' ? 'active' : ''); ?>">Retro</a>
                            <a href="<?php echo e(route('games', ['category' => 'PC'])); ?>"
                                class="button <?php echo e(request()->routeIs('games') && request()->input('category') == 'PC' ? 'active' : ''); ?>">PC</a>
                            <a href="<?php echo e(route('games', ['category' => 'PS4'])); ?>"
                                class="button <?php echo e(request()->routeIs('games') && request()->input('category') == 'PS4' ? 'active' : ''); ?>">PS4</a>
                            <a href="<?php echo e(route('games', ['category' => 'Xbox One'])); ?>"
                                class="button <?php echo e(request()->routeIs('games') && request()->input('category') == 'Xbox One' ? 'active' : ''); ?>">Xbox
                                One</a>
                            <a href="<?php echo e(route('games')); ?>"
                                class="button <?php echo e(request()->routeIs('games') && request()->input('category') == null ? 'active' : ''); ?>">Alle</a>
                        </div>
                    </div>
                    <div class="row col-12 game-cards-container ">
                        <?php $__empty_1 = true; $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="row col-6 col-xs-6 col-md-3">
                                <div class="game-card col-12 bg-appleblue">
                                    <div>
                                        <img src="<?php echo e(asset('storage/' . $game->foto)); ?>" alt="<?php echo e($game->titel); ?>">
                                    </div>
                                    <div class="game-card-info relative col-12 ">
                                        <h2><?php echo e($game->titel); ?></h2>

                                        <p class="p-b-5">Verkoper : </p>
                                        <div class="game-card-kopers-box ">
                                            <?php $__empty_2 = true; $__currentLoopData = $game->userGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userGame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <?php if($userGame->status === 'te koop'): ?>
                                                    <p><i><?php echo e($userGame->user->name); ?> €<?php echo e($userGame->prijs); ?></i></p>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <p>Geen verkopers gevonden</p>
                                            <?php endif; ?>
                                        </div>
                                        <p class="p-t-25 p-b-40">
                                            <?php echo e(implode(', ', $game->platforms->pluck('platform_naam')->toArray())); ?></p>
                                        <div class="game-category  ">
                                            <a class="game-card-button-more-info "
                                                href="<?php echo e(route('game.show', $game->id)); ?>">
                                                Meer Info
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>No games available at the moment.</p>
                        <?php endif; ?>

                    </div>

                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/games.blade.php ENDPATH**/ ?>