<body>

    <?php $__env->startSection('profile-content'); ?>
        <main>
            <h1>Dit is mijn verkoop pagina</h1>

            <div class="container">
                <div class="row col-12">
                    <?php $__empty_1 = true; $__currentLoopData = $userGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userGame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="row col-3">
                            <div class="verkoop-card col-12">

                                <a href="<?php echo e(route('verkoop.show', $userGame->game->id)); ?>">

                                    <img src="<?php echo e(asset('storage/' . $userGame->game->foto)); ?>"
                                        alt="<?php echo e($userGame->game->titel); ?>">
                                    <h2><?php echo e($userGame->game->titel); ?></h2>

                                    <h4>Spel van: <?php echo e(Auth::user()->name); ?></h4>
                                    <p>€<?php echo e($userGame->prijs); ?></p>
                                    <p><?php echo e(implode(', ', $userGame->game->platforms->pluck('platform_naam')->toArray())); ?>

                                    </p>
                                </a>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No games available at the moment.</p>
                    <?php endif; ?>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\profile\mijn-verkoop.blade.php ENDPATH**/ ?>