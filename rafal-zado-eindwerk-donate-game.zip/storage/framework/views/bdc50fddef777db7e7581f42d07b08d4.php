<body>

    <?php $__env->startSection('content'); ?>
        <h1>Events pagina</h1>
    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\events.blade.php ENDPATH**/ ?>