<body>

    <?php $__env->startSection('profile-content'); ?>
        <main class="bg-appleblue">
            <h1>Dit is mijn wishlist pagina</h1>

        </main>
    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\profile\wishlist.blade.php ENDPATH**/ ?>