<div class=<?php echo e(auth()->check() ? 'nav-auth' : 'nav-guest'); ?>>

    <div class="container">






        <header class="row">



            <div class="col-2 col-md-2">
                <img class="header-logo" src="../../../../images/logo.png" alt="">
            </div>
            <div class="row col-9 justify-end ">

                <?php if(auth()->guard()->guest()): ?>
                    <nav class="d-none-mobile nav-guest ">
                        <div>
                            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">HOME</a>
                            <a href="<?php echo e(route('games')); ?>" class="<?php echo e(request()->is('games') ? 'active' : ''); ?>">GAMES</a>
                            
                            <a href="<?php echo e(route('login')); ?>" class="<?php echo e(request()->is('login') ? 'active' : ''); ?>">INLOGGEN</a>
                            <a class="donate-btn" href="<?php echo e(route('donate')); ?>"
                                class="<?php echo e(request()->is('donate') ? 'active' : ''); ?>">DONATIE</a>

                        </div>
                    </nav>
                    <div>

                        
                        <button class="mobile-hamburger-button" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><img
                                class="mobile-menu-appleblue  d-none-tablet m-b-10"
                                src="../../../images/hamburger-menu-purple.png" alt=""></button>

                        <div class="offcanvas offcanvas-end bg-appleblue" tabindex="-1" id="offcanvasRight"
                            aria-labelledby="offcanvasRightLabel">
                            <div class="offcanvas-header">
                                <h5 class="offcanvas-title" id="offcanvasRightLabel"><img class="header-logo"
                                        src="../../images/logo.png" alt=""></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                    aria-label="Close">X</button>
                            </div>
                            <div class="offcanvas-body">
                                <!-- Plaats hier je navigatielinks of andere content -->
                                <div class="flex flex-column nav-mobile">
                                    <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">HOME</a>
                                    <a href="<?php echo e(route('games')); ?>"
                                        class="<?php echo e(request()->is('games') ? 'active' : ''); ?>">GAMES</a>
                                    <a href="<?php echo e(route('events')); ?>"
                                        class="<?php echo e(request()->is('events') ? 'active' : ''); ?>">EVENTS</a>
                                    <a href="<?php echo e(route('login')); ?>"
                                        class="<?php echo e(request()->is('login') ? 'active' : ''); ?>">INLOGGEN</a>
                                    <a class="donate-btn" href="<?php echo e(route('donate')); ?>"
                                        class="<?php echo e(request()->is('donate') ? 'active' : ''); ?>">DONATIE</a>
                                </div>

                            </div>
                        </div>


                    </div>


                <?php endif; ?>

                <?php if(auth()->guard()->check()): ?>
                    <nav class="d-none-mobile nav-auth ">
                        <div>
                            <a href="<?php echo e(route('home')); ?>" class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">HOME</a>

                            <a href="<?php echo e(route('games')); ?>" class="<?php echo e(request()->is('games') ? 'active' : ''); ?>">GAMES</a>
                            <a href="<?php echo e(route('profile')); ?>" class="<?php echo e(request()->is('profile') ? 'active' : ''); ?>">MIJN
                                PROFIEL</a>
                            

                            
                            <a href="<?php echo e(route('logout')); ?>">UITLOGGEN</a>
                            <a class="donate-btn-login" href="<?php echo e(route('donate')); ?>"
                                class="<?php echo e(request()->is('donate') ? 'active' : ''); ?>">DONATIE</a>
                        </div>



                    </nav>
                    <div>
                        
                        <button class="mobile-hamburger-button" type="button" data-bs-toggle="offcanvas"
                            data-bs-target="#offcanvasRight" aria-controls="offcanvasRight"><img
                                class="mobile-menu-appleblue  d-none-tablet m-b-10"
                                src="../../../images/hamburger-menu-appleblue.png" alt=""></button>

                        <div class="offcanvas offcanvas-end bg-purple" tabindex="-1" id="offcanvasRight"
                            aria-labelledby="offcanvasRightLabel">
                            <div class="offcanvas-header">
                                <h5 class="offcanvas-title" id="offcanvasRightLabel"><img class="header-logo"
                                        src="../../images/logo.png" alt=""></h5>
                                <button type="button" class="btn-close" data-bs-dismiss="offcanvas"
                                    aria-label="Close">X</button>
                            </div>
                            <div class="offcanvas-body">
                                <!-- Plaats hier je navigatielinks of andere content -->
                                <div class="flex flex-column nav-mobile">
                                    <a href="<?php echo e(route('home')); ?>"
                                        class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">HOME</a>

                                    <a href="<?php echo e(route('games')); ?>"
                                        class="<?php echo e(request()->is('games') ? 'active' : ''); ?>">GAMES</a>
                                    <a href="<?php echo e(route('profile')); ?>"
                                        class="<?php echo e(request()->is('profile') ? 'active' : ''); ?>">MIJN
                                        PROFIEL</a>
                                    

                                    
                                    <a href="<?php echo e(route('logout')); ?>">UITLOGGEN</a>
                                    <a class="donate-btn-login" href="<?php echo e(route('donate')); ?>"
                                        class="<?php echo e(request()->is('donate') ? 'active' : ''); ?>">DONATIE</a>
                                </div>

                            </div>
                        </div>

                    </div>

                <?php endif; ?>


            </div>
        </header>
    </div>

</div>
<?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\layouts\includes\header.blade.php ENDPATH**/ ?>