<?php $__env->startSection('profile-content'); ?>
    <main class="bg-appleblue profile-index">
        <div class="container flex justify-center align-items-center">
            <div class="row profile-box">
                <div class="col-12">
                    <h1>Game Details: <?php echo e($game->game->titel); ?></h1>
                    <div class="card">
                        <img src="<?php echo e(asset('storage/' . $game->game->foto)); ?>" class="card-img-top" alt="Game Image">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($game->game->titel); ?></h5>
                            <p class="card-text"><?php echo e($game->game->beschrijving); ?></p>
                            <p>Price: €<?php echo e($game->prijs); ?></p>
                            <p>Status: <?php echo e($game->status); ?></p>
                            <?php if($game->buyer): ?>
                                <p>Buyer: <?php echo e($game->buyer->name); ?></p>
                            <?php endif; ?>
                            <?php if($game->seller): ?>
                                <p>Seller: <?php echo e($game->seller->name); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views\userGame\soldGame.blade.php ENDPATH**/ ?>