<body>
    <?php $__env->startSection('title-profile', 'Verkoop'); ?>

    <?php $__env->startSection('profile-content'); ?>
        <main class="bg-appleblue">
            <div class="container">
                <div class="row ">
                    <div class="col-12">
                        <h1 class="p-t-50 p-b-25 verkoop-h1">Verkoop je spel</h1>

                    </div>

                    <form class="edit-profil-form row col-12" action="<?php echo e(route('verkoop.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>

                        <div class="col-12">

                            <div>
                                <div class="row gap10 col-12">
                                    <div class="edit-profil-box flex flex-column col-6 col-md-4">
                                        <label for="platform_naam">Platform:</label>
                                        <select id="platform_naam" class="select-wrapper" name="platform_naam"
                                            onchange="fetchGames()" value="<?php echo e(old('platform_naam')); ?>">
                                            <option value="">Selecteer een platform</option>
                                            <option value="1">PS4</option>
                                            <option value="2">Xbox One</option>
                                            <option value="3">PC</option>
                                            <option value="4">Retro</option>
                                        </select>
                                        <?php $__errorArgs = ['platform_naam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box ">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="edit-profil-box flex flex-column col-6 col-md-4">
                                        <label for="game_id">Kies een spel:</label>
                                        <select id="game_id" name="game_id" value="<?php echo e(old('game_id')); ?>">
                                            <option value="">Selecteer een spel</option>
                                        </select>
                                        <div class="error-box row col-5">
                                            <?php $__errorArgs = ['game_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="edit-profil-box flex flex-column col-8">
                                    <label for="beschrijving">Waarom verkoop je het spel : </label>
                                    <textarea name="beschrijving" id="beschrijving" cols="30" rows="10" value="<?php echo e(old('beschrijving')); ?>"></textarea>
                                    <div class="error-box row col-5">
                                        <?php $__errorArgs = ['beschrijving'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                            </div>


                            <div>
                                <h2>Kenmerken</h2>
                                <div>
                                    <div class="edit-profil-box flex flex-column col-6 col-md-4">
                                        <label for="conditie">Conditie:</label>
                                        <select id="conditie" name="conditie" value="<?php echo e(old('conditie')); ?>">
                                            <option value="Nieuw">Nieuw</option>
                                            <option value="Zo Goed Als Nieuw">Zo Goed Als Nieuw</option>
                                            <option value="Gebruikt">Gebruikt</option>
                                            <option value="Niet werkend">Niet Werkend</option>
                                            <option value="Nog verpakt">Nog Verpakt</option>


                                        </select>
                                        <?php $__errorArgs = ['conditie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="error-box">
                                                <p><?php echo e($message); ?></p>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                    </div>


                                </div>
                            </div>
                            <div>
                                <h2>Status</h2>
                                <div>
                                    <div class="edit-profil-box flex flex-column col-6 col-md-4">
                                        <label for="Status">Status:</label>
                                        <select id="Status" name="Status">
                                            <option value="te koop">Te koop</option>
                                            <option value="verkocht">Verkocht</option>


                                        </select>

                                        <div class="error-box row col-5">
                                            <?php $__errorArgs = ['Status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <p><?php echo e($message); ?></p>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                    </div>
                                </div>
                            </div>
                            <div>
                                <h2>Prijs</h2>
                                <div>
                                    <div class="edit-profil-box flex flex-column col-6 col-md-4">
                                        <label for="prijs ">Prijs:</label>
                                        <input type="number" id="prijs" name="prijs" min="0.01" step="0.01"
                                            value="<?php echo e(old('prijs')); ?>" required>
                                    </div>
                                    <div class="error-box row col-5">
                                        <?php $__errorArgs = ['prijs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <p><?php echo e($message); ?></p>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="edit-profil-box flex flex-column col-12 ">

                                <div>

                                    <button type="submit">Verkoop je spel</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </main>
    <?php $__env->stopSection(); ?>

    <?php $__env->startPush('scripts'); ?>
        <script>
            function fetchGames() {
                let platform = document.getElementById('platform_naam').value;
                console.log("Platform value:", platform);
                if (platform) {
                    fetch(`/fetch-games/${platform}`)
                        .then(response => response.json())
                        .then(data => {
                            let gameSelect = document.getElementById('game_id');
                            gameSelect.innerHTML = '';
                            data.forEach(game => {
                                let option = new Option(game.titel, game.id);
                                gameSelect.add(option);
                            });
                        })
                        .catch(error => console.error('Error fetching games:', error));
                } else {
                    let gameSelect = document.getElementById('game_id');
                    gameSelect.innerHTML = '<option value="">Selecteer een spel</option>';
                }
            }
        </script>
    <?php $__env->stopPush(); ?>



</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/verkoop/create.blade.php ENDPATH**/ ?>