<body>
    <?php $__env->startSection('profile-content'); ?>
        <main class="bg-appleblue">
            <div class="container">
                <div class="row container-show-game col-12">
                    <div class="col-12 col-md-5">
                        <h1 class="text-purple">Update:</h1>
                        <h2><?php echo e($userGame->game->titel); ?></h2>
                        <p><?php echo e($userGame->beschrijving); ?></p>
                    </div>

                    <div class="col-12 col-md-6 flex justify-center">
                        <img src="<?php echo e(asset('storage/' . $userGame->game->foto)); ?>" alt="<?php echo e($userGame->game->titel); ?>"
                            style="width: 300px;">
                    </div>
                </div>
            </div>

            <div class="container padding-con">
                <form action="<?php echo e(route('verkoop.update', $userGame->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div>
                        <div class="row gap10 col-12">
                            <div class="edit-profil-box flex flex-column col-8">
                                <label for="beschrijving">Werk je beschrijving bij:</label>
                                <textarea name="beschrijving" id="beschrijving" cols="30" rows="10"><?php echo e(old('beschrijving', $userGame->beschrijving)); ?></textarea>
                            </div>
                        </div>

                        <div>
                            <h2>Kenmerken</h2>
                            <div class="row gap10 col-12">
                                <div class="edit-profil-box flex flex-column col-8">
                                    <label for="conditie">Conditie:</label>
                                    <select id="conditie" name="conditie">
                                        <option value="Nieuw"
                                            <?php echo e(old('conditie', $userGame->conditie) == 'Nieuw' ? 'selected' : ''); ?>>Nieuw
                                        </option>
                                        <option value="Zo Goed Als Nieuw"
                                            <?php echo e(old('conditie', $userGame->conditie) == 'Zo Goed Als Nieuw' ? 'selected' : ''); ?>>
                                            Zo Goed Als Nieuw</option>
                                        <option value="Gebruikt"
                                            <?php echo e(old('conditie', $userGame->conditie) == 'Gebruikt' ? 'selected' : ''); ?>>
                                            Gebruikt</option>
                                        <option value="Niet Werkend"
                                            <?php echo e(old('conditie', $userGame->conditie) == 'Niet Werkend' ? 'selected' : ''); ?>>
                                            Niet Werkend</option>
                                        <option value="Nog Verpakt"
                                            <?php echo e(old('conditie', $userGame->conditie) == 'Nog Verpakt' ? 'selected' : ''); ?>>
                                            Nog Verpakt</option>
                                    </select>
                                    <?php $__errorArgs = ['conditie'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="error-box">
                                            <p><?php echo e($message); ?></p>
                                        </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div>
                            <h2>Prijs</h2>
                            <div class="row gap10 col-12">
                                <div class="edit-profil-box flex flex-column col-4">
                                    <label for="prijs">Prijs:</label>
                                    <input type="number" id="prijs" name="prijs" min="0.01" step="0.01"
                                        value="<?php echo e(old('prijs', $userGame->prijs)); ?>" required>
                                </div>
                                <?php $__errorArgs = ['prijs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="error-box">
                                        <p><?php echo e($message); ?></p>
                                    </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div>
                            <button type="submit">Sla op</button>
                        </div>
                    </div>
                </form>
            </div>
        </main>
    <?php $__env->stopSection(); ?>
</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/verkoop/edit.blade.php ENDPATH**/ ?>