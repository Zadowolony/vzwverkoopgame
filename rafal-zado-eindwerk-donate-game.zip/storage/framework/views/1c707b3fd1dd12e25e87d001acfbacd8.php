<?php $__env->startSection('title-profile', 'Gekochte Games'); ?>

<?php $__env->startSection('profile-content'); ?>
    <main class="bg-appleblue">



        <div class="container  flex flex-column justify-center h-100">

            <div class="row p-t-50 gap50">



                <div class="col-12 col-md-6  ">

                    <div class=" flex justify-center align-items-center">
                        <img class="border-radius-25" src="<?php echo e(asset('storage/' . $game->game->foto)); ?>"
                            alt="<?php echo e($game->titel); ?>">
                    </div>


                </div>

                <div class="col-12 p-b-25 col-md-5 flex flex-column justify-center">
                    <div class="col-12 flex justify-center game_titel">
                        <h1><?php echo e($game->game->titel); ?></h1>
                    </div>




                    <div class="col-12  row align-items-center">

                        <div class="col-4 flex ">
                            <p class="p-t-25">Prijs:</p>
                        </div>
                        <div class="game_category_console col-6 ">
                            <p>€<?php echo e($game->prijs); ?></p>
                        </div>

                    </div>


                    <div class="col-12  row align-items-center">

                        <div class="col-4 flex ">
                            <p class="p-t-25">Status :</p>
                        </div>
                        <div class="game_category_console  col-6 ">
                            <p class="p-l-10 p-r-10"><?php echo e($game->status); ?></p>
                        </div>

                    </div>

                    <div class=" col-12  row align-items-center">
                        <div class="col-4 flex ">
                            <p class=" p-t-25">Buyer:
                            </p>
                        </div>
                        <div class="game_category_console col-6 ">
                            <?php if($game->buyer): ?>
                                <?php echo e($game->buyer->name); ?></p>
                            <?php endif; ?>


                        </div>
                    </div>

                    <div class=" col-12  row align-items-center">
                        <div class="col-4 flex ">
                            <p class=" p-t-25">Seller:
                            </p>
                        </div>
                        <div class="game_category_console col-6 ">

                            <?php if($game->seller): ?>
                                <p><?php echo e($game->seller->name); ?></p>
                            <?php endif; ?>

                        </div>
                    </div>






                </div>

            </div>



        </div>







    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/userGame/details.blade.php ENDPATH**/ ?>