<body>

    <?php $__env->startSection('title-profile', 'Mijn Profiel'); ?>


    <?php $__env->startSection('profile-content'); ?>
        <main class=" bg-appleblue profile-index">

            <div class="container  flex justify-center align-items-center row col-12">
                <div class="row   profile-box  ">

                    <div class=" col-12 col-md-6 profile-box-image-name ">


                        <h1 class="">Welcome <span class="profile-name"><?php echo e(Auth::user()->name); ?></span></h1>



                        <div class="col-5 col-md-8 flex justify-center">
                            <?php if(Auth::user()->profile_picture): ?>
                                <img class="profile-image" src="<?php echo e(asset('storage/' . Auth::user()->profile_picture)); ?>"
                                    alt="Profile Picture" style="width: 150px; height: 150px;">
                            <?php else: ?>
                                <p><img src="../images/logo.png" alt="No user Image"></p>
                            <?php endif; ?>
                        </div>


                    </div>

                    <div class="col-12 col-md-6 profile-box-beschrijving m-b-50">
                        <div class="profil-beschrijving ">
                            <p><?php echo e(Auth::user()->over_mij); ?></p>
                        </div>

                        <div class=" profil-links row col-12 m-t-25 ">
                            <div class="row justify-around gap20 align-items-center">
                                <a class="col-5 " href="<?php echo e(route('profile.edit')); ?>" class="button">Bewerk mijn
                                    profiel</a>
                                <a class="col-5" href="<?php echo e(route('donate')); ?>" class="button">Doe een donatie</a>
                                <a class="col-5" href="<?php echo e(route('verkoop.create')); ?>" class="button">Verkoop een spel</a>
                                <?php if(auth()->user()->isAdmin()): ?>
                                    <a class="col-5" href="#">Voeg Event toe</a>
                                    <a class="col-5" href="<?php echo e(route('admin.create-game')); ?>">Voeg een game toe</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

            <div class="container-full bg-purple">
                <div class="container">
                    <div class="row">
                        <div class="col-12 p-t-50 p-b-50">
                            <h2>Games die ik verkoop</h2>
                        </div>


                        <div class="row col-12 p-b-50">
                            <?php $__empty_1 = true; $__currentLoopData = $sellingGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userGame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class=" col-6 col-xs-4 col-md-3 ">
                                    <!-- Each card takes up 3 columns in a 12-column grid, allowing for 4 cards per row -->
                                    <div class="game-card bg-yellow full-card-link relative ">
                                        <a href="<?php echo e(route('verkoop.show', $userGame->id)); ?>" class="">
                                            <img src="<?php echo e(asset('storage/' . $userGame->game->foto)); ?>" alt="Game Image">
                                            <div class="game-card-info">
                                                <h3><?php echo e($userGame->game->titel); ?></h3>
                                                <p>€<?php echo e($userGame->prijs); ?></p>
                                            </div>
                                        </a>

                                        <div class="flex justify-end align-items-center game-card-link ">
                                            <a href="<?php echo e(route('verkoop.edit', $userGame->id)); ?>" class="btn btn-primary">
                                                <i class="fa-solid fa-pen-to-square"></i>
                                            </a>

                                            <form method="POST"
                                                action="<?php echo e(route('verkoop.remove-sale', $userGame->id)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <button type="submit" class=""><i
                                                        class="fa-solid fa-xmark"></i></button>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12 p-b-50">
                                    <p>Geen spellen te koop.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>




            <div class="container-full bg-appleblue">
                <div class="container ">
                    <div class="row p-b-50">
                        <div class="col-12 p-t-50 p-b-25">
                            <h2>Gekochte games</h2>
                        </div>
                        <div class="row col-12 p-b-50">
                            <?php $__empty_1 = true; $__currentLoopData = $purchasedGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userGame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-6 col-xs-4 col-md-3">
                                    <!-- Each card takes up 3 columns in a 12-column grid, allowing for 4 cards per row -->
                                    <div class="game-card bg-yellow full-card-link relative">
                                        <a href="<?php echo e(route('userGame.details', ['userId' => auth()->id(), 'gameId' => $userGame->id, 'type' => 'bought'])); ?>"
                                            class=" ">
                                            <img src="<?php echo e(asset('storage/' . $userGame->game->foto)); ?>" alt="Game Image">
                                            <div class="game-card-info">
                                                <h3><?php echo e($userGame->game->titel); ?></h3>
                                                <p>€<?php echo e($userGame->prijs); ?></p>
                                                <!-- Notice here it uses $userGame->prijs -->
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Geen gekochte games gevonden.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            </div>


            <div class="container-full bg-purple">
                <div class="container ">
                    <div class="row p-b-50">
                        <div class="col-12 p-t-50 p-b-25">
                            <h2>Games die ik verkocht heb.</h2>
                        </div>
                        <?php $__empty_1 = true; $__currentLoopData = $soldGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class=" col-6 col-xs-4 col-md-3 ">
                                <!-- Each card takes up 3 columns in a 12-column grid, allowing for 4 cards per row -->
                                <div class="game-card bg-yellow full-card-link relative ">
                                    <a href="<?php echo e(route('userGame.soldGame', ['userId' => auth()->id(), 'gameId' => $game->game->id])); ?>"
                                        class=" ">
                                        <img src="<?php echo e(asset('storage/' . $game->game->foto)); ?>" alt="Game Image">
                                        <div class="game-card-info">
                                            <h3><?php echo e($game->game->titel); ?></h3>
                                            <p>€<?php echo e($game->prijs); ?></p>
                                        </div>
                                    </a>


                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p>Geen verkochte games gevonden.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="container-full bg-appleblue">
                <div class="container ">
                    <div class="row p-b-50">
                        <div class="col-12 p-t-50 p-b-25">
                            <h2>Wishlist</h2>
                        </div>
                        <div class="row col-12  ">
                            <?php $__empty_1 = true; $__currentLoopData = $wishlistGames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php echo $__env->make('profile.layouts.includes.wishlist-card', ['game' => $game], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>Geen games in de wishlist gevonden.</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>


        </main>
    <?php $__env->stopSection(); ?>



</body>

</html>

<?php echo $__env->make('profile.layouts.profile-default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\vzwverkoopgame\resources\views/profile/index.blade.php ENDPATH**/ ?>