<!DOCTYPE html>
<html>

<head>
    <title>Game Available for Purchase!</title>
</head>

<body>
    <h1>{{ $gameTitle }} is Now Available!</h1>
    <p>Description: {{ $gameDescription }}</p>
    <p>Price: €{{ $gamePrice }}</p>
    <p>Visit our website to buy it now!</p>
</body>

</html>
