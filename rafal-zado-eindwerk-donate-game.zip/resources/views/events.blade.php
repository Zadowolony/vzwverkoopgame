@extends('layouts.default')

<body>

    @section('content')
        <h1>Events pagina</h1>
    @endsection



</body>

</html>
