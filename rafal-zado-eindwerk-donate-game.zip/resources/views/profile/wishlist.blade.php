@extends('profile.layouts.profile-default')

<body>

    @section('profile-content')
        <main class="bg-appleblue">
            <h1>Dit is mijn wishlist pagina</h1>

        </main>
    @endsection



</body>

</html>
