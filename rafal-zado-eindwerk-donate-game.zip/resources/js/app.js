import './bootstrap';
import 'bootstrap'


// document.addEventListener('DOMContentLoaded', function () {
//     // Select all elements with the class 'hero-img'
//     const heroImages = document.querySelectorAll('.hero-img');
//     let lastScroll = 0;

//     window.addEventListener('scroll', function () {
//         const scrolled = window.scrollY;

//         heroImages.forEach(heroImage => {
//             if (scrolled > lastScroll) {
//                 // Scrolling down
//                 heroImage.style.transform = `translateY(${scrolled * -0.05}px)`;
//             } else {
//                 // Scrolling up
//                 heroImage.style.transform = `translateY(${scrolled * -0.05}px)`;
//             }
//         });

//         lastScroll = scrolled; // Update lastScroll to current position after the calculations
//     });
// });
